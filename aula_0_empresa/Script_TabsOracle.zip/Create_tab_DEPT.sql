create table dept 
(DEPTNO number(2) CONSTRAINT Dept_DeptNo_PK Primary Key, 
DNAME varchar2(14),LOC varchar2(13));




