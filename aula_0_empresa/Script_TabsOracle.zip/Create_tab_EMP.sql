create table emp
(empno number(4) constraint Emp_empno_pk primary key,
ename varchar2(10),job varchar2(9), mgr number(4),
hiredate date, sal number(7,2), comm number(7,2),
deptno number(2) CONSTRAINT Emp_Dept_DeptNo_FK References Dept); 
